//
//  TiSocial.h
//  ti.social
//
//  Created by Your Name
//  Copyright (c) 2024 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiSocial.
FOUNDATION_EXPORT double TiSocialVersionNumber;

//! Project version string for TiSocial.
FOUNDATION_EXPORT const unsigned char TiSocialVersionString[];

#import "TiSocialModuleAssets.h"
